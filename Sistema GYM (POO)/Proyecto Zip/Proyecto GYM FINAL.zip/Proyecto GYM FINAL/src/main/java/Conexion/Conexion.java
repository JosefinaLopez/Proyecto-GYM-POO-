package Conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;
import java.sql.*;

public class Conexion {
   //Declarar parámetros
        Connection conex;
        
  public Connection abrirConexion ()
    {
        
        
        String cadenaConex = "jdbc:mysql://localhost:3306/gym";
        String user = "root";
        String pass= "";
        
        try
        {
         
         conex= DriverManager.getConnection(cadenaConex,user,pass);
         if(conex!=null)
         {
             JOptionPane.showMessageDialog(null,"Conexion hecha");
         }
          
            
        }catch (SQLException e)
        {
           JOptionPane.showMessageDialog(null,"Conexión Fallida " + e);
            
            
        }
         
        return conex;
    }
    
     //este metodo nos retorna la conexion
    public Connection getConnection(){
        return conex;
    }
    
  
    
   
}