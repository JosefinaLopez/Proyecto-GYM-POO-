/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

import Conexion.Conexion;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author Daneo Silva
 */
public class Horarios {
    private int idHorario;
    private String modalidad;
    private String periodo;
    private int tarifaId;

    public Horarios() {
        
    }
    
    public Horarios(int idHorario, String modalidad, String periodo, int tarifaId) {
        this.idHorario = idHorario;
        this.modalidad = modalidad;
        this.periodo = periodo;
        this.tarifaId = tarifaId;
    }

    public int getIdHorario() {
        return idHorario;
    }

    public void setIdHorario(int idHorario) {
        this.idHorario = idHorario;
    }

    public String getModalidad() {
        return modalidad;
    }

    public void setModalidad(String modalidad) {
        this.modalidad = modalidad;
    }

    public String getPeriodo() {
        return periodo;
    }

    public void setPeriodo(String periodo) {
        this.periodo = periodo;
    }

    public int getTarifaId() {
        return tarifaId;
    }

    public void setTarifaId(int tarifaId) {
        this.tarifaId = tarifaId;
    }
      public int registrarInformacion(String modalidad,String periodo, int taritaId)
    {
        Conexion conx = new Conexion ();// Clase Conexión
        int insert = -1;
        
        String consulta = "Insert into horario (Modalidad,Periodo,TarifaId) Values ('"+modalidad+"','"+periodo+"','"+taritaId+"')";

        try
        {
            Connection con = conx.abrirConexion();
            
            Statement sentencia = con.createStatement();
            
            insert = sentencia.executeUpdate(consulta);
                                
            con.close();
         
        }catch (SQLException e)
        {
            JOptionPane.showMessageDialog(null, "Registro Fallido"+e);
            
        }
        
        return insert;
    }
      
      public int buscarInformacion(int id)
    {
        Conexion conx = new Conexion();
        int buscar = -1;
        String consulta = "SELECT H.Modalidad, H.Periodo FROM HORARIO AS H WHERE H.Id = '"+id+"' ";
        
        try
        {
            Connection con = conx.abrirConexion();
            Statement sentencia = con.createStatement();
            ResultSet  resultado= sentencia.executeQuery(consulta); 
            
            while(resultado.next())
            {
                setModalidad(resultado.getString("Modalidad"));
                setPeriodo(resultado.getString("Periodo"));
                
                
                buscar = 1;
            }
            con.close();
            
        }catch (SQLException e)
        {
            JOptionPane.showMessageDialog(null, "Registro Fallido"+e);
        }
        return buscar;
 
    }
      
      public int modificarInformacion(int id, String modalidad, String periodo, int tarifaId) {
        
        int modificar=-1;
        
        Conexion conx = new Conexion ();
    
    String consulta = "UPDATE horario set Modalidad='"+modalidad+"', Periodo='"+periodo+"', TarifaId='"+tarifaId+"' where Id= '"+id+"'";
       
        try
        {
            Connection con = conx.abrirConexion();
            
            Statement sentencia = con.createStatement();
            
            modificar = sentencia.executeUpdate(consulta);
            
            con.close();
        }
        catch(SQLException e)
        {
            JOptionPane.showMessageDialog(null, "Registro Fallido "+e);
        }
        return modificar;
        
    }
    
    
    
    
}
