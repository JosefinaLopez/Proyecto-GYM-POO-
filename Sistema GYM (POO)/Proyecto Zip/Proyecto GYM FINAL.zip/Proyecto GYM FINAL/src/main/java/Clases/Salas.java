/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

import Conexion.Conexion;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author Daneo Silva
 */
public class Salas {
    
    private int idSalas;
    private String nombreSala;
    private int sucursalId;

    public Salas() {
        
        
    }
    
    public Salas(int idSalas, String nombreSala, int cucursalId) {
        this.idSalas = idSalas;
        this.nombreSala = nombreSala;
        this.sucursalId = cucursalId;
    }

    public int getIdSalas() {
        return idSalas;
    }

    public void setIdSalas(int idSalas) {
        this.idSalas = idSalas;
    }

    public String getNombreSala() {
        return nombreSala;
    }

    public void setNombreSala(String nombreSala) {
        this.nombreSala = nombreSala;
    }

    public int getSucursalId() {
        return sucursalId;
    }

    public void setSucursalId(int cucursalId) {
        this.sucursalId = cucursalId;
    }
    
       public int registrarInformacion(String nombreSala,int sucursalId)
    {
        Conexion conx = new Conexion ();// Clase Conexión
        int insert = -1;
        
        String consulta = "Insert into sala (Nombre,SucursalId) Values ('"+nombreSala+"','"+sucursalId+"')";

        try
        {
            Connection con = conx.abrirConexion();
            
            Statement sentencia = con.createStatement();
            
            insert = sentencia.executeUpdate(consulta);
                                
            con.close();
         
        }catch (SQLException e)
        {
            JOptionPane.showMessageDialog(null, "Registro Fallido"+e);
            
        }
        
        return insert;
    }
       
       public int buscarInformacion(int id)
    {
        Conexion conx = new Conexion();
        int buscar = -1;
        String consulta = "SELECT s.Nombre FROM sala AS s INNER JOIN sucursal AS sc ON s.SucursalId = sc.Id WHERE s.Id = '"+id+"' ";
        
        try
        {
            Connection con = conx.abrirConexion();
            Statement sentencia = con.createStatement();
            ResultSet  resultado= sentencia.executeQuery(consulta); 
            
            while(resultado.next())
            {
                setNombreSala(resultado.getString("Nombre"));
                
                
                buscar = 1;
            }
            con.close();
            
        }catch (SQLException e)
        {
            JOptionPane.showMessageDialog(null, "Registro Fallido"+e);
        }
        return buscar;
 
    }
       
       public int modificarInformacion(int id, String nombre, int sucursal) {
        
        int modificar=-1;
        
        Conexion conx = new Conexion ();
    
         String consulta = "UPDATE sala set Nombre='"+nombre+"', SucursalId='"+sucursal+"' where Id= '"+id+"'";
       
        try
        {
            Connection con = conx.abrirConexion();
            
            Statement sentencia = con.createStatement();
            
            modificar = sentencia.executeUpdate(consulta);
            
            con.close();
        }
        catch(SQLException e)
        {
            JOptionPane.showMessageDialog(null, "Registro Fallido "+e);
        }
        return modificar;
        
    }
    
    
    
    
}
