/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

import Conexion.Conexion;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author Daneo Silva
 */
public class Sucursal {
    
    private int idSucursal;
    private String nombreSucursal;
    private String ubiSucursal;

    public Sucursal() {
        
    }
    

    public Sucursal(int idSucursal, String nombreSucursal, String ubiSucursal) {
        this.idSucursal = idSucursal;
        this.nombreSucursal = nombreSucursal;
        this.ubiSucursal = ubiSucursal;
    }

    public int getIdSucursal() {
        return idSucursal;
    }

    public void setIdSucursal(int idSucursal) {
        this.idSucursal = idSucursal;
    }

    public String getNombreSucursal() {
        return nombreSucursal;
    }

    public void setNombreSucursal(String nombreSucursal) {
        this.nombreSucursal = nombreSucursal;
    }

    public String getUbiSucursal() {
        return ubiSucursal;
    }

    public void setUbiSucursal(String ubiSucursal) {
        this.ubiSucursal = ubiSucursal;
    }
    
       public int registrarInformacion(String nombreSucursal,String ubiSucursal)
    {
        Conexion conx = new Conexion ();// Clase Conexión
        int insert = -1;
        
        String consulta = "Insert into sucursal (Nombre,Ubicacion) Values ('"+nombreSucursal+"','"+ubiSucursal+"')";

        try
        {
            Connection con = conx.abrirConexion();
            
            Statement sentencia = con.createStatement();
            
            insert = sentencia.executeUpdate(consulta);
                                
            con.close();
         
        }catch (SQLException e)
        {
            JOptionPane.showMessageDialog(null, "Registro Fallido"+e);
            
        }
        
        return insert;
    }
       
       public int buscarInformacion(int id)
    {
        Conexion conx = new Conexion();
        int buscar = -1;
        String consulta = " SELECT s.Nombre, s.Ubicacion FROM sucursal AS s WHERE s.Id = '"+id+"' ";
        
        try
        {
            Connection con = conx.abrirConexion();
            Statement sentencia = con.createStatement();
            ResultSet  resultado= sentencia.executeQuery(consulta); 
            
            while(resultado.next())
            {
                setNombreSucursal(resultado.getString("Nombre"));
                setUbiSucursal(resultado.getString("Ubicacion"));
                
                
                buscar = 1;
            }
            con.close();
            
        }catch (SQLException e)
        {
            JOptionPane.showMessageDialog(null, "Registro Fallido"+e);
        }
        return buscar;
 
    }
       
       public int modificarInformacion(int id, String nombreSucursal, String ubiSucursal) {
        
        int modificar=-1;
        
        Conexion conx = new Conexion ();
    
    String consulta = "UPDATE sucursal set Nombre='"+nombreSucursal+"', Ubicacion='"+ubiSucursal+"' where Id= '"+id+"'";
       
        try
        {
            Connection con = conx.abrirConexion();
            
            Statement sentencia = con.createStatement();
            
            modificar = sentencia.executeUpdate(consulta);
            
            con.close();
        }
        catch(SQLException e)
        {
            JOptionPane.showMessageDialog(null, "Registro Fallido "+e);
        }
        return modificar;
        
    }
       
       
    
    
    
    
    
}
