/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

/**
 *
 * @author Daneo Silva
 */
public class Actividad {
    
    private int idActi;
    private String nombreActividad;
    private String tipoActividad;
    private int salasId;
    private int horariosId;

    public Actividad( ) {
        
    }
    
    public Actividad(int idActi, String nombreActividad, String tipoActividad, int salasId, int horariosId) {
        this.idActi = idActi;
        this.nombreActividad = nombreActividad;
        this.tipoActividad = tipoActividad;
        this.salasId = salasId;
        this.horariosId = horariosId;
    }

    public int getIdActi() {
        return idActi;
    }

    public void setIdActi(int idActi) {
        this.idActi = idActi;
    }

    public String getNombreActividad() {
        return nombreActividad;
    }

    public void setNombreActividad(String nombreActividad) {
        this.nombreActividad = nombreActividad;
    }

    public String getTipoActividad() {
        return tipoActividad;
    }

    public void setTipoActividad(String tipoActividad) {
        this.tipoActividad = tipoActividad;
    }

    public int getSalasId() {
        return salasId;
    }

    public void setSalasId(int salasId) {
        this.salasId = salasId;
    }

    public int getHorariosId() {
        return horariosId;
    }

    public void setHorariosId(int horariosId) {
        this.horariosId = horariosId;
    }
    
    
    
}
