/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

import Conexion.Conexion;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author Daneo Silva
 */
public class Tarifa {
    
    private int idTarifa;
    private String nombreTarifa;
    private float precio;
    private String descuentoTarifa;
    private String fechaCompra;

    public Tarifa() {
        
    }
    
    
    public Tarifa(int idTarifa, String nombreTarifa, float precio, String descuentoTarifa, String fechaCompra) {
        this.idTarifa = idTarifa;
        this.nombreTarifa = nombreTarifa;
        this.precio = precio;
        this.descuentoTarifa = descuentoTarifa;
        this.fechaCompra = fechaCompra;
    }

    public int getIdTarifa() {
        return idTarifa;
    }

    public void setIdTarifa(int idTarifa) {
        this.idTarifa = idTarifa;
    }

    public String getNombreTarifa() {
        return nombreTarifa;
    }

    public void setNombreTarifa(String nombreTarifa) {
        this.nombreTarifa = nombreTarifa;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    public String getDescuentoTarifa() {
        return descuentoTarifa;
    }

    public void setDescuentoTarifa(String descuentoTarifa) {
        this.descuentoTarifa = descuentoTarifa;
    }

    public String getFechaCompra() {
        return fechaCompra;
    }

    public void setFechaCompra(String fechaCompra) {
        this.fechaCompra = fechaCompra;
    }
    
    public int registrarInformacion(String nomTarifa,float precio, String descuento, String fecha)
    {
        Conexion conx = new Conexion ();// Clase Conexión
        int insert = -1;
        
        String consulta = "Insert into tarifa (Nombre,Precio, Descuento, FechaCompra) Values ('"+nomTarifa+"','"+precio+"','"+descuento+"','"+fecha+"')";

        try
        {
            Connection con = conx.abrirConexion();
            
            Statement sentencia = con.createStatement();
            
            insert = sentencia.executeUpdate(consulta);
                                
            con.close();
         
        }catch (SQLException e)
        {
            JOptionPane.showMessageDialog(null, "Registro Fallido"+e);
            
        }
        
        return insert;
    }          
    
    public int buscarInformacion(int id)
    {
        Conexion conx = new Conexion();
        int buscar = -1;
        String consulta = "SELECT t.Nombre, t.Precio,t.Descuento,t.FechaCompra FROM tarifa AS t WHERE t.Id = '"+id+"' ";
        
        try
        {
            Connection con = conx.abrirConexion();
            Statement sentencia = con.createStatement();
            ResultSet  resultado= sentencia.executeQuery(consulta); 
            
            while(resultado.next())
            {
                setNombreTarifa(resultado.getString("Nombre"));
                setPrecio(resultado.getFloat("Precio"));
                this.descuentoTarifa =(resultado.getString("Descuento"));
                setFechaCompra(resultado.getString("FechaCompra"));
                
                buscar = 1;
            }
            con.close();
            
        }catch (SQLException e)
        {
            JOptionPane.showMessageDialog(null, "Registro Fallido"+e);
        }
        return buscar;
 
    }
    
    public int modificarInformacion(int id, String nombreTarifa, float precio, String descuentoTarifa, String fechaCompra) {
        
        int modificar=-1;
        
        Conexion conx = new Conexion ();
    
    String consulta = "UPDATE tarifa set Nombre='"+nombreTarifa+"', Precio='"+precio+"', Descuento='"+descuentoTarifa+"', FechaCompra='"+fechaCompra+"' where Id= '"+id+"'";
       
        try
        {
            Connection con = conx.abrirConexion();
            
            Statement sentencia = con.createStatement();
            
            modificar = sentencia.executeUpdate(consulta);
            
            con.close();
        }
        catch(SQLException e)
        {
            JOptionPane.showMessageDialog(null, "Registro Fallido "+e);
        }
        return modificar;
        
    }
    
}
