/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;
import java.sql.SQLException;
import Conexion.Conexion;
import javax.swing.JOptionPane;
import java.sql.*;


/**
 *
 * @author Daneo Silva
 */
public class Clientes extends Personas {
    
    private int edad;
    private int estadoCliente;
    private int sucursalId;
    private int tarifaId;

    public Clientes() {
        
        super();
    }

    public Clientes(int edad, int estadoCliente, int sucursalId, int tarifaId, int id, String nombre, String apellido, String sexo, String contraseña) {
        super(id, nombre, apellido, sexo, contraseña);
        this.edad = edad;
        this.estadoCliente = estadoCliente;
        this.sucursalId = sucursalId;
        this.tarifaId = tarifaId;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public int getEstadoCliente() {
        return estadoCliente;
    }

    public void setEstadoCliente(int estadoCliente) {
        this.estadoCliente = estadoCliente;
    }

    public int getSucursalId() {
        return sucursalId;
    }

    public void setSucursalId(int sucursalId) {
        this.sucursalId = sucursalId;
    }

    public int getTarifaId() {
        return tarifaId;
    }

    public void setTarifaId(int tarifaId) {
        this.tarifaId = tarifaId;
    }
      public int registrarInformacion(String nom,String ape,int edad,String sexo, String Contrasena, int estado, int sucursal, int tarifa)
    {
        Conexion conx = new Conexion ();// Clase Conexión
        int insert = -1;
        
        String consulta = "Insert into cliente (Nombre,Apellido,Edad,Sexo,Contrasena,EstadoClienteId, SucursalId, TarifaId) Values ('"+nom+"','"+ape+"','"+edad+"','"+sexo+"','"+Contrasena+"', '"+estado+"','"+sucursal+"','"+tarifa+"')";

        try
        {
            Connection con = conx.abrirConexion();
            
            Statement sentencia = con.createStatement();
            
            insert = sentencia.executeUpdate(consulta);
                                
            con.close();
         
        }catch (SQLException e)
        {
            JOptionPane.showMessageDialog(null, "Registro Fallido"+e);
            
        }
        
        return insert;
    }             
    
   public int buscarInformacion(int id)
    {
        Conexion conx = new Conexion();
        int buscar = -1;
        String consulta = "select c.Nombre,c.Apellido,c.Edad,c.Sexo,c.Contrasena,ea.Id, s.Id, t.Id from cliente as c INNER JOIN estadocliente as ea ON c.EstadoClienteId = ea.Id INNER JOIN sucursal as s ON c.SucursalId = s.Id INNER JOIN tarifa as t ON c.TarifaId = t.Id where c.id = '"+id+"' ";
        
        try
        {
            Connection con = conx.abrirConexion();
            Statement sentencia = con.createStatement();
            ResultSet  resultado= sentencia.executeQuery(consulta); 
            
            while(resultado.next())
            {
                setNombre(resultado.getString("Nombre"));
                setApellido(resultado.getString("Apellido"));
                this.edad = (resultado.getInt("Edad"));
                setSexo(resultado.getString("Sexo"));
                setContraseña(resultado.getString("Contrasena"));
                buscar = 1;
            }
            con.close();
            
        }catch (SQLException e)
        {
            JOptionPane.showMessageDialog(null, "Registro Fallido"+e);
        }
        return buscar;
 
    }
    
    
    public int modificarInformacion(int id, String nombre, String apellido, int edad, String sexo, String contrasena, int estado, int sucursal, int tarifa) {
        
        int modificar=-1;
        
        Conexion conx = new Conexion ();
    
    String consulta = "UPDATE Cliente set Nombre='"+nombre+"', Apellido='"+apellido+"', Edad='"+edad+"', Sexo='"+sexo+"',Contrasena='"+contrasena+"', EstadoClienteId='"+estado+"', SucursalId='"+sucursal+"',TarifaId='"+tarifa+"' where Id= '"+id+"'";
       
        try
        {
            Connection con = conx.abrirConexion();
            
            Statement sentencia = con.createStatement();
            
            modificar = sentencia.executeUpdate(consulta);
            
            con.close();
        }
        catch(SQLException e)
        {
            JOptionPane.showMessageDialog(null, "Registro Fallido "+e);
        }
        return modificar;
        
    }
    
}
