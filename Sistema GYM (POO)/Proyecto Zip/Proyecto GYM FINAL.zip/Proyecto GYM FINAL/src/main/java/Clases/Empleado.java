/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

import Conexion.Conexion;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author Daneo Silva
 */
public class Empleado extends Personas {
    
    private double salario;
    private String ocupacion;
    private int sucursalId;

    public Empleado() {
        super();
    }
    
    
    public Empleado(double salario, String ocupacion, int sucursalId, int id, String nombre, String apellido, String sexo, String contraseña) {
        super(id, nombre, apellido, sexo, contraseña);
        this.salario = salario;
        this.ocupacion = ocupacion;
        this.sucursalId = sucursalId;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public String getOcupacion() {
        return ocupacion;
    }

    public void setOcupacion(String ocupacion) {
        this.ocupacion = ocupacion;
    }

    public int getSucursalId() {
        return sucursalId;
    }

    public void setSucursalId(int sucursalId) {
        this.sucursalId = sucursalId;
    }
     public int registrarInformacion(String nom,String ape,double salario,String ocupacion,String contrasena, int sucursal)
    {
        Conexion conx = new Conexion ();// Clase Conexión
        int insert = -1;
        
        String consulta = "Insert into empleado (Nombre,Apellido,Salario,Ocupacion,Contrasena, SucursalId) Values ('"+nom+"','"+ape+"','"+salario+"','"+ocupacion+"','"+contrasena+"','"+sucursal+"')";

        try
        {
            Connection con = conx.abrirConexion();
            
            Statement sentencia = con.createStatement();
            
            insert = sentencia.executeUpdate(consulta);
                                
            con.close();
         
        }catch (SQLException e)
        {
            JOptionPane.showMessageDialog(null, "Registro Fallido"+e);
            
        }
        
        return insert;
    }
     
     public int buscarInformacion(int id)
    {
        Conexion conx = new Conexion();
        int buscar = -1;
        String consulta = "SELECT e.Nombre, e.Apellido,e.Salario,e.Ocupacion,e.Contrasena FROM empleado AS E INNER JOIN sucursal AS S ON e.SucursalId = s.Id WHERE E.Id = '"+id+"'";
        try
        {
            Connection con = conx.abrirConexion();
            Statement sentencia = con.createStatement();
            ResultSet  resultado= sentencia.executeQuery(consulta); 
            
            while(resultado.next())
            {
                setNombre(resultado.getString("Nombre"));
                setApellido(resultado.getString("Apellido"));
                setContraseña(resultado.getString("Contrasena"));
                setSalario(resultado.getDouble("Salario"));
                setOcupacion(resultado.getString("Ocupacion"));
                
                buscar = 1;
            }
            con.close();
            
        }catch (SQLException e)
        {
            JOptionPane.showMessageDialog(null, "Registro Fallido"+e);
        }
        return buscar;
 
    }
     
     public int modificarInformacion(int id, String nombre, String apellido, double salario, String ocupacion, String contrasena, int sucursal) {
        
        int modificar=-1;
        
        Conexion conx = new Conexion ();
    
         String consulta = "UPDATE empleado set Nombre='"+nombre+"', Apellido='"+apellido+"', Salario='"+salario+"', Ocupacion='"+ocupacion+"',Contrasena='"+contrasena+"', SucursalId='"+sucursal+"' where Id= '"+id+"'";
       
        try
        {
            Connection con = conx.abrirConexion();
            
            Statement sentencia = con.createStatement();
            
            modificar = sentencia.executeUpdate(consulta);
            
            con.close();
        }
        catch(SQLException e)
        {
            JOptionPane.showMessageDialog(null, "Registro Fallido "+e);
        }
        return modificar;
        
    }
     
     
    
    
    
}
